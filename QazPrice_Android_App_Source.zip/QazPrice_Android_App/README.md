# QazPrice Android wrapper

This Android Studio project wraps the current standalone QazPrice site in a native Android WebView. The web UI and catalogue are bundled locally in `app/src/main/assets/index.html`; the original HTML project remains unchanged.

## Included

- Catalogue, search, recipe presets, basket, CSP planning, and store ranking from the current QazPrice HTML.
- Kazakh/Russian/English switch from the website.
- 2GIS links open in the phone browser.
- Local storage is enabled for basket and favorites.

## Local AI limitation

The website's Qwen feature expects the separate QazPrice Python service and Ollama to run on the same machine. In this APK, `127.0.0.1` is the phone itself, so local Qwen generation is unavailable unless a phone-compatible backend is separately configured. The app still includes the recipe book and all catalogue-based features.

## Build an APK

Open this folder in Android Studio and select **Build > Build APK(s)**. The project uses Android Gradle Plugin 8.9.2, Gradle 8.11.1, JDK 17, and Android SDK Platform 35. For these versions, the Android Gradle Plugin requires JDK 17 and Gradle 8.11.1. See the official compatibility table: https://developer.android.com/build/releases/agp-8-9-0-release-notes

The first Android SDK setup asks the developer to review and accept Google's Android SDK license. After building, Android Studio places the APK under `app/build/outputs/apk/debug/`.

This project has not yet been compiled into an APK because the machine has no Android SDK/JDK installed and the SDK license has not been accepted.
